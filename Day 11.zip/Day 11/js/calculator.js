
function display(value){
    document.getElementById("rst").value+=value;
}

function removelastone(){

    var remove=document.getElementById("rst").value;
    document.getElementById("rst").value = remove.slice(0,-1);

}

function clr(){
    document.getElementById("rst").value = " ";
}

function finalrst(){
    var ad=document.getElementById("rst").value;
    var rem=document.getElementById("rst").value;
    ad=eval(rem);
    document.getElementById("rst").value=ad;
}